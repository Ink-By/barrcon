import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BarrMoney extends StatefulWidget{
  State<StatefulWidget> createState() => _BarrMoneyState();
}

class _BarrMoneyState extends State {
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            Container(
              margin: const EdgeInsets.fromLTRB(20, 10, 5, 0),
              child: const Text(
                '바르머니',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                ),
              ),
            ),
            Container(
                margin: const EdgeInsets.fromLTRB(250, 10, 5, 0),
                child: const Text(
                  "4,000원",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                  ),
                )
            ),
          ],
        ),
        Row(
          children: <Widget>[
            TextButton(
              onPressed: () {
                //  송금 페이지 열기
              },
              child: const Text(
                '송금',
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
            ),
            TextButton(
              onPressed: () {
                //  송금 페이지 열기
              },
              child: const Text(
                '충전',
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(left: 240),
              child:
              IconButton (
                constraints: const BoxConstraints(),
                icon: const Icon(
                  Icons.shopping_cart,
                  color: Colors.white,
                ),
                onPressed: (){ },
              ),
            ),
            Container(
              child: TextButton(
                onPressed: () {
                },
                child: const Text(
                  '결제 내역',
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}