import 'package:flutter/cupertino.dart';

class BankCategory extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 20, 0, 0),
      height: 600,
      child: Column(
        children: <Widget>[
          Text(
              '은행선택',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          Row(
            children: <Widget>[

            ],
          )
        ],
      )
    );
  }
}