import 'package:barrcon/sendAndCharge/send_tab_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:barrcon/sendAndCharge/bank_category.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BarrCon',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: DefaultTabController(
          // 탭의 수 설정
          length: 2,
          child: Scaffold(
            appBar: AppBar(
              toolbarHeight: 0,
              bottom: const TabBar(
                tabs: [
                  Tab(text: '송금'),
                  Tab(text: '충전')
                ],
              ),
            ),
            body: TabBarView(
              children: <Widget>[
                Column(
                  children: <Widget>[
                const SendTabPage(),  //  송금
                Column(
                  children: [
                    Text('data'),
                  ],
                )  //  충전
              ],
            ),
          ),
        ),
      ),
    );
  }
}