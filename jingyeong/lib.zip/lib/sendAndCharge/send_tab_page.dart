import 'package:barrcon/sendAndCharge/bank_category.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class SendTabPage extends StatefulWidget {
  const SendTabPage({super.key});

  @override
  State<StatefulWidget> createState() => _SendTabPageState();

}

class _SendTabPageState extends State {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Container(
          margin: const EdgeInsets.fromLTRB(5, 15, 5, 0),
          child: Row(
              children: <Widget>[
                Container(
                    height: 50,
                    child: OutlinedButton(
                        onPressed: () {
                          showModalBottomSheet<void>(
                            context: context,
                            builder: (BuildContext context) {
                              return BankCategory();
                            },
                          );
                        },
                        child: Text(
                          '은행명',
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15
                          ),
                        )
                    )
                ),
                Container(
                    margin: const EdgeInsets.only(left: 5),
                    width: 400,
                    child: const TextField(
                      decoration: InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: '계좌번호',
                      ),
                    )
                )
              ]
          ),
        ),
        ElevatedButton(
          onPressed: () {  },
          
        )
      ],
    );
  }

}