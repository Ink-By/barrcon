package com.adeelsafdar.loginsignup.login_signup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
