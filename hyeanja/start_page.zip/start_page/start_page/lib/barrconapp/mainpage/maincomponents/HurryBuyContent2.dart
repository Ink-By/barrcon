import 'package:flutter/material.dart';
import '../../../helpers/transform/transform.dart';
import './HurryBuyWriter2.dart';
import './GeneratedWidget13.dart';
import './HurryBuyContentTime2.dart';
import './HurryBuyContentTitle2.dart';

class HurryBuyContent2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {return Container(
      child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,children: [
        Flexible(
          flex: 15,
          child:
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            HurryBuyContentTitle2(),
            HurryBuyWriter2()
          ]),
        ),
        Flexible(flex: 3, child: SizedBox()),
        Flexible(
          flex: 2,
          child: Container(
              child: HurryBuyContentTime2(),
              margin: EdgeInsets.only(top: 10)),
        ),
        Flexible(
          flex: 2,
          child: Icon(Icons.send),
        )
      ]));
  }
}
