import 'package:flutter/material.dart';
import './HurrySellTitle.dart';
import './HurrySellContents.dart';
import './DivideLine.dart';

class HurrySell extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      HurrySellTitle(),
      DivideLine(),
      HurrySellContents()
    ]);
  }
}
