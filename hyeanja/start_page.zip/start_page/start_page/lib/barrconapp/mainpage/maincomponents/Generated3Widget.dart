import 'package:flutter/material.dart';
import '../../../helpers/svg/svg.dart';

class Generated3Widget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 326.0,
      height: 87.0,
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.green,
          width: 3,
        ),
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(63, 0, 0, 0),
            offset: Offset(1.0, 1.0),
            blurRadius: 2.0,
          )
        ],
      ),
      child: SvgWidget(painters: [
        SvgPathPainter.fill()
          ..addPath(
              'M0 10C0 4.47715 4.47715 0 10 0L316 0C321.523 0 326 4.47715 326 10L326 77C326 82.5228 321.523 87 316 87L10 87C4.47716 87 0 82.5229 0 77L0 10Z')
          ..color = Color.fromARGB(255, 255, 255, 255),
        SvgPathPainter.stroke(
          1.0,
          strokeJoin: StrokeJoin.miter,
        )
          ..addPath(
              'M10 1L316 1L316 -1L10 -1L10 1ZM325 10L325 77L327 77L327 10L325 10ZM316 86L10 86L10 88L316 88L316 86ZM1 77L1 10L-1 10L-1 77L1 77ZM10 86C5.02945 86 1 81.9706 1 77L-1 77C-1 83.0751 3.92488 88 10 88L10 86ZM325 77C325 81.9706 320.971 86 316 86L316 88C322.075 88 327 83.0751 327 77L325 77ZM316 1C320.971 1 325 5.02944 325 10L327 10C327 3.92487 322.075 -1 316 -1L316 1ZM10 -1C3.92487 -1 -1 3.92487 -1 10L1 10C1 5.02944 5.02944 1 10 1L10 -1Z')
          ..color = Color.fromARGB(51, 0, 0, 0)
          ..addClipPath(
              'M0 10C0 4.47715 4.47715 0 10 0L316 0C321.523 0 326 4.47715 326 10L326 77C326 82.5228 321.523 87 316 87L10 87C4.47716 87 0 82.5229 0 77L0 10Z'),
      ]),
    );
  }
}
