import 'package:flutter/material.dart';
import './HurryBuyContentTime1.dart';
import './HurryBuyContentTitle1.dart';
import './HurryBuyWriter1.dart';
import './GeneratedWidget16.dart';

class HurryBuyContent1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,children: [
          Flexible(
            flex: 15,
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              HurryBuyContentTitle1(),
              HurryBuyWriter1()
            ]),
          ),
          Flexible(flex: 3, child: SizedBox()),
          Flexible(
            flex: 2,
            child: Container(
                child: HurryBuyContentTime1(),
                margin: EdgeInsets.only(top: 10)),
          ),
          Flexible(
            flex: 2,
            child: Icon(Icons.send),
          )
        ]));
  }
}
