import 'package:flutter/material.dart';

class MainAlarm extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Flexible(
          flex: 2,
          child: Icon(Icons.campaign, size: 30),
        ),
        Flexible(
          flex: 1,
          child: const Padding(
            padding: (EdgeInsets.all(10)),
          ),
        ),
        Flexible(
          flex: 13,
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: Colors.green,
                width: 3,
              ),
            ),
            child: Text(
              '''공차 5000원 기프티콘” 판매가 완료되었습니다.''',
              textAlign: TextAlign.left,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 15.0,
                fontWeight: FontWeight.w700,
                color: Colors.black,
              ),
            ),
          ),
        )
      ],
    );
  }
}
