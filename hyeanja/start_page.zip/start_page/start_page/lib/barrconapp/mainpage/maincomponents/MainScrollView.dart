import 'package:flutter/material.dart';
import './MainExceptAlarm.dart';
import './MainAlarm.dart';

class MainScrollView extends StatelessWidget {
  const MainScrollView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            children: [
              Container(
                width: double.infinity,
                height: 20.0,
                child: MainAlarm(),
              ),
              const Padding(
                padding: (EdgeInsets.only(top: 10)),
              ),
              Container(
                margin: (EdgeInsets.all(15)),
                child: MainExceptAlarm(),
              ),
            ],
          ));
    }));
  }
}
