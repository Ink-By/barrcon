import 'package:flutter/material.dart';
import './DivideLine.dart';
import './HurryBuyContent2.dart';
import './HurryBuyContent1.dart';
import './HurryBuyTitle.dart';

class HurryBuy extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: Column(children: [
      HurryBuyTitle(),
      DivideLine(),
      Stack(
        children: [
          Container(
              height: 110.0,
              margin: const EdgeInsets.only(top: 10),
              child: Container(color: const Color.fromARGB(63, 0, 0, 0))),
          Column(children: [
            Container(
                height: 40.0,
                margin: const EdgeInsets.fromLTRB(10, 20, 10, 5),
                child: HurryBuyContent1()),
            Container(
                height: 40.0,
                margin: const EdgeInsets.fromLTRB(10, 5, 10, 10),
                child: HurryBuyContent2())
          ])
        ],
      )
    ]));
  }
}
