import 'package:flutter/material.dart';
import './HurryBuyTitleText.dart';
import './HurryBuyComment.dart';

class HurryBuyTitle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        textBaseline: TextBaseline.ideographic,
        children: [
      Flexible(
        flex: 3,
        child: HurryBuyTitleText()
      ),
      Flexible(
        flex: 10,
        child: HurryBuyComment()
      ),
      Flexible(
        flex: 3,
        child: Container(height: 25),
      ),
      Flexible(
        flex: 1,
        child: Container(
          height: 50,
          child: Icon(Icons.add, size:40),
        ),
      ),
    ]);
  }
}
