import 'package:flutter/material.dart';
import 'dart:io';
import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

class Submit extends StatefulWidget {
  const Submit({Key? key}) : super(key: key);

  @override
  State<Submit> createState() => _SubmitState();
}

class _SubmitState extends State<Submit> {

  File? _profileImage;

  final _signupFormKey = GlobalKey<FormState>();


  Future _pickProfileImage() async {
    try {
      final image = await ImagePicker().pickImage(source: ImageSource.gallery);
      if(image == null) return;

      final imageTemporary = File(image.path);
      setState(() => _profileImage = imageTemporary);
    } on PlatformException catch (e) {
      debugPrint('Failed to pick image error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    File f;
    return SingleChildScrollView(
      child: Column(
        children: [
          const Padding(
            padding: (EdgeInsets.only(top: 50)),
          ),


          SizedBox(
            width: 350,
            height: 350,
            child: CircleAvatar(
              backgroundColor: Colors.grey.shade200,
              backgroundImage: _profileImage != null ? FileImage(_profileImage!) : null,
              child: Stack(
                children: [
                  Positioned(
                    bottom: 5,
                    right: 5,
                    child: GestureDetector(
                      onTap: _pickProfileImage,
                      child: Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(
                          color: Colors.blue.shade400,
                          border: Border.all(color: Colors.white, width: 3),
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: const Icon(
                          Icons.camera_alt_sharp,
                          color: Colors.white,
                          size: 25,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          /*-------------------------------*/
          Form(
            child: Theme(
              data: ThemeData(
                primaryColor: Colors.black,
                inputDecorationTheme: const InputDecorationTheme(
                    labelStyle: TextStyle(color: Colors.black, fontSize: 15.0)),
              ),
              child: Container(
                padding: const EdgeInsets.all(40.0),
                child: Column(
                  children: [
                    const TextField(
                      decoration: InputDecoration(labelText: '상품명'),
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const TextField(
                      decoration: InputDecoration(labelText: '카테고리'),
                      keyboardType: TextInputType.text,
                    ),
                    const TextField(
                      decoration: InputDecoration(labelText: '유효기간'),
                      keyboardType: TextInputType.datetime,
                    ),
                    const TextField(
                      decoration: InputDecoration(labelText: '가격'),
                      keyboardType: TextInputType.text,
                    ),
                    const SizedBox(
                      height: 40.0,
                    ),
                    ButtonTheme(
                        minWidth: 100.0,
                        height: 50.0,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: Colors.blueAccent),
                            child: const Text('등록'),
                            onPressed: () {}))
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
