import 'package:flutter/material.dart';

void main() {
  // 비동기로 실행됨(이벤트 루프에 등록된다)
  runApp(MyApp());
  // sleep(Duration(seconds: 2));
  // print("main 종료");
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SafeArea(
        child: Scaffold(
          body: Center(
            child: Image.asset(
              "assets/시작이미지.gif",
              width: 600,
              height: 350,
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}