import 'dart:async';
import 'package:flutter/material.dart';
import 'package:start_page/homescreen.dart';



void main() {
  // 비동기로 실행됨(이벤트 루프에 등록된다)
  runApp(MaterialApp(
    home: new SplashScreen(),
    routes: <String, WidgetBuilder>{
      '/HomeScreen': (BuildContext context) => new HomeScreen()
    },
  ));
}
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => new _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  startTime() async {
    var _duration = new Duration(seconds: 7);
    return new Timer(_duration, navigationPage);
  }

  void navigationPage() {
    Navigator.of(context).pushReplacementNamed('/HomeScreen');
  }

  @override
  void initState() {
    super.initState();
    startTime();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SafeArea(
        child: Scaffold(
          body: Center(
            child: Image.asset(
              "assets/시작이미지.gif",
              width: 600,
              height: 350,
              fit: BoxFit.fill,
            ),
          ),
        ),
      ),
    );
  }
}

