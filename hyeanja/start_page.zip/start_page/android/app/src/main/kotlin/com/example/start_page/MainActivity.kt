package com.example.start_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
