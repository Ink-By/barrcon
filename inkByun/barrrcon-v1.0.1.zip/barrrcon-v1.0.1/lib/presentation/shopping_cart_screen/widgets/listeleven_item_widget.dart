import 'package:barrrcon/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ListelevenItemWidget extends StatelessWidget {
  ListelevenItemWidget();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: getVerticalSize(
        18.00,
      ),
      width: getHorizontalSize(
        227.00,
      ),
      margin: getMargin(
        top: 5.8200035,
        bottom: 5.8200035,
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Align(
            alignment: Alignment.center,
            child: Text(
              "투썸플레이스 밀크생크림 초콜릿 수플레",
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.left,
              style: TextStyle(
                color: ColorConstant.blueGray900,
                fontSize: getFontSize(
                  14,
                ),
                fontFamily: 'Source Sans Pro',
                fontWeight: FontWeight.w600,
                height: 1.29,
              ),
            ),
          ),
          Align(
            alignment: Alignment.center,
            child: Container(
              height: getVerticalSize(
                18.00,
              ),
              width: getHorizontalSize(
                227.00,
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "투썸플레이스 밀크생크림 초콜릿 수플레",
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: ColorConstant.blueGray900,
                        fontSize: getFontSize(
                          14,
                        ),
                        fontFamily: 'Source Sans Pro',
                        fontWeight: FontWeight.w600,
                        height: 1.29,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      "투썸플레이스 밀크생크림 초콜릿 수플레",
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color: ColorConstant.blueGray900,
                        fontSize: getFontSize(
                          14,
                        ),
                        fontFamily: 'Source Sans Pro',
                        fontWeight: FontWeight.w600,
                        height: 1.29,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
