import 'package:barrrcon/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class List7bb1dd9bf6964TwoItemWidget extends StatelessWidget {
  List7bb1dd9bf6964TwoItemWidget();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: getMargin(
        top: 8.5,
        bottom: 8.5,
      ),
      padding: getPadding(
        left: 7,
        top: 10,
        right: 7,
        bottom: 10,
      ),
      decoration: BoxDecoration(
        color: ColorConstant.whiteA700,
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2.00,
            ),
            blurRadius: getHorizontalSize(
              2.00,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomImageView(
            imagePath: ImageConstant.starbucks_coffee1,
            height: getVerticalSize(
              100.00,
            ),
            width: getHorizontalSize(
              99.00,
            ),
            margin: getMargin(
              top: 5,
              bottom: 12,
            ),
          ),
          Padding(
            padding: getPadding(
              left: 9,
              top: 16,
              bottom: 14,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: getPadding(
                    left: 6,
                  ),
                  child: Text(
                    "스타벅스 카페 아메리카노 T",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      color: ColorConstant.blueGray900,
                      fontSize: getFontSize(
                        14,
                      ),
                      fontFamily: 'Source Sans Pro',
                      fontWeight: FontWeight.w600,
                      height: 1.29,
                    ),
                  ),
                ),
                Padding(
                  padding: getPadding(
                    left: 5,
                    top: 11,
                  ),
                  child: Text(
                    "4,050원",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      color: ColorConstant.black900,
                      fontSize: getFontSize(
                        14,
                      ),
                      fontFamily: 'Source Sans Pro',
                      fontWeight: FontWeight.w400,
                      height: 1.29,
                    ),
                  ),
                ),
                Container(
                  width: getHorizontalSize(
                    221.00,
                  ),
                  margin: getMargin(
                    top: 13,
                  ),
                  padding: getPadding(
                    left: 30,
                    top: 2,
                    right: 69,
                    bottom: 2,
                  ),
                  decoration: BoxDecoration(
                    color: ColorConstant.gray50,
                    borderRadius: BorderRadius.circular(
                      getHorizontalSize(
                        5.00,
                      ),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: ColorConstant.black90026,
                        spreadRadius: getHorizontalSize(
                          2.00,
                        ),
                        blurRadius: getHorizontalSize(
                          2.00,
                        ),
                        offset: Offset(
                          0,
                          1,
                        ),
                      ),
                    ],
                  ),
                  child: Text(
                    "구매 확정 완료",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      color: ColorConstant.black900,
                      fontSize: getFontSize(
                        14,
                      ),
                      fontFamily: 'Source Sans Pro',
                      fontWeight: FontWeight.w600,
                      height: 1.29,
                    ),
                  ),
                ),
              ],
            ),
          ),
          CustomImageView(
            svgPath: ImageConstant.imgClose,
            height: getVerticalSize(
              13.00,
            ),
            width: getHorizontalSize(
              11.00,
            ),
            margin: getMargin(
              left: 15,
              bottom: 104,
            ),
          ),
        ],
      ),
    );
  }
}
