class ImageConstant {
  static String imgLogo1 = 'assets/images/img_logo1.png';

  //starbucks_coffee
  static String starbucks_coffee = 'assets/images/starbucks_coffee.png';

  //more
  static String more = 'assets/images/more.svg';

  //coffee_cate
  static String coffee_cate = 'assets/images/coffee_cate.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  //starbucks_set
  static String starbucks_set =
      'assets/images/starbucks_set.png';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  //barcode
  static String barcode = 'assets/images/barcode.png';

  //twosome_cake
  static String twosome_cake = 'assets/images/twosome_cake.png';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgBookmark = 'assets/images/img_bookmark.svg';

  //hambuger category
  static String hambuger = 'assets/images/hambuger.png';

  //movie_ticket
  static String movie_ticket = 'assets/images/movie_ticket.png';

  //starbucks_coffee1
  static String starbucks_coffee1 =
      'assets/images/starbucks_coffee1.png';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String pizza_54x54 = 'assets/images/pizza_54x54.png';

  //gift_box
  static String gift_box = 'assets/images/gift_box.svg';

  //store
  static String store = 'assets/images/store.png';

  //fourcolor_cake
  static String fourcolor_cake = 'assets/images/fourcolor_cake.png';

  //million_gift
  static String million_gift =
      'assets/images/million_gift.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
