import '../read_barcode_screen/widgets/k0_item_widget.dart';
import 'package:barrrcon/core/app_export.dart';
import 'package:barrrcon/widgets/app_bar/appbar_image.dart';
import 'package:barrrcon/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class ReadBarcodeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          width: size.width,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              CustomImageView(
                imagePath: ImageConstant.starbucks_coffee,
                height: getSize(
                  286.00,
                ),
                width: getSize(
                  286.00,
                ),
                margin: getMargin(
                  top: 75,
                ),
              ),
              CustomImageView(
                imagePath: ImageConstant.barcode,
                height: getVerticalSize(
                  100.00,
                ),
                width: getHorizontalSize(
                  289.00,
                ),
                margin: getMargin(
                  top: 10,
                ),
              ),
              Padding(
                padding: getPadding(
                  left: 6,
                  top: 7,
                ),
                child: ListView.separated(
                  physics: BouncingScrollPhysics(),
                  shrinkWrap: true,
                  separatorBuilder: (context, index) {
                    return Container(
                      height: getVerticalSize(
                        5.00,
                      ),
                      width: getHorizontalSize(
                        387.00,
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.black90007,
                      ),
                    );
                  },
                  itemCount: 2,
                  itemBuilder: (context, index) {
                    return K0ItemWidget();
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
