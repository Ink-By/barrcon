import 'package:barrrcon/core/app_export.dart';
import 'package:barrrcon/widgets/app_bar/appbar_image.dart';
import 'package:barrrcon/widgets/app_bar/custom_app_bar.dart';
import 'package:barrrcon/widgets/custom_button.dart';
import 'package:barrrcon/widgets/custom_drop_down.dart';
import 'package:barrrcon/widgets/custom_icon_button.dart';
import 'package:barrrcon/widgets/custom_search_view.dart';
import 'package:flutter/material.dart';

class CategoryScreen extends StatelessWidget {
  TextEditingController searchbarController = TextEditingController();

  List<String> dropdownItemList = ["test", "test1", "test2", "test3"];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          width: size.width,
          padding: getPadding(
            top: 73,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              CustomSearchView(
                width: 345,
                focusNode: FocusNode(),
                controller: searchbarController,
                hintText: "SEARCH",
                suffix: Padding(
                  padding: EdgeInsets.only(
                    right: getHorizontalSize(
                      15.00,
                    ),
                  ),
                  child: IconButton(
                    onPressed: () {
                      searchbarController.clear;
                    },
                    icon: Icon(
                      Icons.clear,
                      color: Colors.grey.shade600,
                    ),
                  ),
                ),
                suffixConstraints: BoxConstraints(
                  minWidth: getHorizontalSize(
                    27.00,
                  ),
                  minHeight: getVerticalSize(
                    27.00,
                  ),
                ),
              ),
              Align(
                alignment: Alignment.centerRight,
                child: Container(
                  width: getHorizontalSize(
                    115.00,
                  ),
                  padding: getPadding(
                    left: 12,
                    right: 12,
                  ),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(
                      getHorizontalSize(
                        8.00,
                      ),
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      CustomDropDown(
                        width: 87,
                        focusNode: FocusNode(),
                        icon: Container(
                          margin: getMargin(
                            left: 19,
                          ),
                          child: CustomImageView(
                            svgPath: ImageConstant.imgArrowdown,
                          ),
                        ),
                        hintText: "가격순",
                        margin: getMargin(
                          top: 10,
                        ),
                        items: dropdownItemList,
                        onChanged: (value) {},
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 14,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        CustomIconButton(
                          height: 54,
                          width: 54,
                          child: CustomImageView(
                            imagePath: ImageConstant.hambuger,
                          ),
                        ),
                      ],
                    ),
                        Padding(
                          padding: getPadding(
                            left: 13,
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              CustomIconButton(
                                height: 54,
                                width: 54,
                                child: CustomImageView(
                                  svgPath: ImageConstant.hambuger,
                                ),
                              ),
                              Padding(
                                padding: getPadding(
                                  top: 8,
                                ),
                                child: Text(
                                  "패스트푸드",
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.left,
                                  style: TextStyle(
                                    color: ColorConstant.gray400,
                                    fontSize: getFontSize(
                                      12,
                                    ),
                                    fontFamily: 'Inter',
                                    fontWeight: FontWeight.w700,
                                    height: 1.25,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),


                    Padding(
                      padding: getPadding(
                        left: 13,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CustomIconButton(
                            height: 54,
                            width: 54,
                            child: CustomImageView(
                              svgPath: ImageConstant.coffee_cate,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 8,
                            ),
                            child: Text(
                              "카페",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: ColorConstant.gray400,
                                fontSize: getFontSize(
                                  12,
                                ),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w700,
                                height: 1.25,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: getPadding(
                        left: 13,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CustomIconButton(
                            height: 54,
                            width: 54,
                            child: CustomImageView(
                              imagePath: ImageConstant.pizza_54x54,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 8,
                            ),
                            child: Text(
                              "치킨/피자",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: ColorConstant.gray400,
                                fontSize: getFontSize(
                                  12,
                                ),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w700,
                                height: 1.25,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: getPadding(
                        left: 13,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CustomIconButton(
                            height: 54,
                            width: 54,
                            child: CustomImageView(
                              imagePath: ImageConstant.store,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 8,
                            ),
                            child: Text(
                              "편의점/잡화",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: ColorConstant.gray400,
                                fontSize: getFontSize(
                                  12,
                                ),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w700,
                                height: 1.25,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: getPadding(
                        left: 13,
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          CustomIconButton(
                            height: 54,
                            width: 54,
                            variant: IconButtonVariant.FillBluegray10001,
                            padding: IconButtonPadding.PaddingAll15,
                            child: CustomImageView(
                              svgPath: ImageConstant.more,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              top: 8,
                            ),
                            child: Text(
                              "더보기",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: ColorConstant.black900,
                                fontSize: getFontSize(
                                  12,
                                ),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w700,
                                height: 1.25,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 44,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: getHorizontalSize(
                        139.00,
                      ),
                      padding: getPadding(
                        left: 7,
                        top: 6,
                        right: 7,
                        bottom: 6,
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.whiteA700,
                        border: Border.all(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1.00,
                          ),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: ColorConstant.black9003f,
                            spreadRadius: getHorizontalSize(
                              2.00,
                            ),
                            blurRadius: getHorizontalSize(
                              2.00,
                            ),
                            offset: Offset(
                              0,
                              4,
                            ),
                          ),
                        ],
                      ),
                      child: Text(
                        "영화 티켓 / 팝콘",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: ColorConstant.black900,
                          fontSize: getFontSize(
                            13,
                          ),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w700,
                          height: 1.23,
                        ),
                      ),
                    ),
                    Container(
                      width: getHorizontalSize(
                        139.00,
                      ),
                      margin: getMargin(
                        left: 13,
                      ),
                      padding: getPadding(
                        left: 30,
                        top: 6,
                        right: 31,
                        bottom: 6,
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.whiteA700,
                        border: Border.all(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1.00,
                          ),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: ColorConstant.black9003f,
                            spreadRadius: getHorizontalSize(
                              2.00,
                            ),
                            blurRadius: getHorizontalSize(
                              2.00,
                            ),
                            offset: Offset(
                              0,
                              4,
                            ),
                          ),
                        ],
                      ),
                      child: Text(
                        "아이스크림",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: ColorConstant.black900,
                          fontSize: getFontSize(
                            13,
                          ),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w700,
                          height: 1.23,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 15,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: getHorizontalSize(
                        139.00,
                      ),
                      padding: getPadding(
                        left: 7,
                        top: 6,
                        right: 7,
                        bottom: 6,
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.whiteA700,
                        border: Border.all(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1.00,
                          ),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: ColorConstant.black9003f,
                            spreadRadius: getHorizontalSize(
                              2.00,
                            ),
                            blurRadius: getHorizontalSize(
                              2.00,
                            ),
                            offset: Offset(
                              0,
                              4,
                            ),
                          ),
                        ],
                      ),
                      child: Text(
                        "게임",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: ColorConstant.black900,
                          fontSize: getFontSize(
                            13,
                          ),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w700,
                          height: 1.23,
                        ),
                      ),
                    ),
                    Container(
                      width: getHorizontalSize(
                        139.00,
                      ),
                      margin: getMargin(
                        left: 13,
                      ),
                      padding: getPadding(
                        left: 11,
                        top: 6,
                        right: 11,
                        bottom: 6,
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.whiteA700,
                        border: Border.all(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1.00,
                          ),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: ColorConstant.black9003f,
                            spreadRadius: getHorizontalSize(
                              2.00,
                            ),
                            blurRadius: getHorizontalSize(
                              2.00,
                            ),
                            offset: Offset(
                              0,
                              4,
                            ),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          CustomImageView(
                            svgPath: ImageConstant.gift_box,
                            height: getSize(
                              18.00,
                            ),
                            width: getSize(
                              18.00,
                            ),
                          ),
                          Padding(
                            padding: getPadding(
                              left: 37,
                              top: 2,
                              right: 38,
                            ),
                            child: Text(
                              "뷰티",
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.left,
                              style: TextStyle(
                                color: ColorConstant.black900,
                                fontSize: getFontSize(
                                  13,
                                ),
                                fontFamily: 'Inter',
                                fontWeight: FontWeight.w700,
                                height: 1.23,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 15,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: getHorizontalSize(
                        139.00,
                      ),
                      padding: getPadding(
                        left: 19,
                        top: 6,
                        right: 19,
                        bottom: 6,
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.whiteA700,
                        border: Border.all(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1.00,
                          ),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: ColorConstant.black9003f,
                            spreadRadius: getHorizontalSize(
                              2.00,
                            ),
                            blurRadius: getHorizontalSize(
                              2.00,
                            ),
                            offset: Offset(
                              0,
                              4,
                            ),
                          ),
                        ],
                      ),
                      child: Text(
                        "모바일 상품권",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: ColorConstant.black900,
                          fontSize: getFontSize(
                            13,
                          ),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w700,
                          height: 1.23,
                        ),
                      ),
                    ),
                    Container(
                      width: getHorizontalSize(
                        139.00,
                      ),
                      margin: getMargin(
                        left: 13,
                      ),
                      padding: getPadding(
                        left: 30,
                        top: 6,
                        right: 48,
                        bottom: 6,
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.whiteA700,
                        border: Border.all(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1.00,
                          ),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: ColorConstant.black9003f,
                            spreadRadius: getHorizontalSize(
                              2.00,
                            ),
                            blurRadius: getHorizontalSize(
                              2.00,
                            ),
                            offset: Offset(
                              0,
                              4,
                            ),
                          ),
                        ],
                      ),
                      child: Text(
                        "주유",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: ColorConstant.black900,
                          fontSize: getFontSize(
                            13,
                          ),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w700,
                          height: 1.23,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: getPadding(
                  top: 15,
                  bottom: 5,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: getHorizontalSize(
                        139.00,
                      ),
                      padding: getPadding(
                        left: 30,
                        top: 6,
                        right: 30,
                        bottom: 6,
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.whiteA700,
                        border: Border.all(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1.00,
                          ),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: ColorConstant.black9003f,
                            spreadRadius: getHorizontalSize(
                              2.00,
                            ),
                            blurRadius: getHorizontalSize(
                              2.00,
                            ),
                            offset: Offset(
                              0,
                              4,
                            ),
                          ),
                        ],
                      ),
                      child: Text(
                        "놀이공원",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: ColorConstant.black900,
                          fontSize: getFontSize(
                            13,
                          ),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w700,
                          height: 1.23,
                        ),
                      ),
                    ),
                    Container(
                      width: getHorizontalSize(
                        139.00,
                      ),
                      margin: getMargin(
                        left: 13,
                      ),
                      padding: getPadding(
                        left: 30,
                        top: 6,
                        right: 30,
                        bottom: 6,
                      ),
                      decoration: BoxDecoration(
                        color: ColorConstant.whiteA700,
                        border: Border.all(
                          color: ColorConstant.gray200,
                          width: getHorizontalSize(
                            1.00,
                          ),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: ColorConstant.black9003f,
                            spreadRadius: getHorizontalSize(
                              2.00,
                            ),
                            blurRadius: getHorizontalSize(
                              2.00,
                            ),
                            offset: Offset(
                              0,
                              4,
                            ),
                          ),
                        ],
                      ),
                      child: Text(
                        "가전 / 가구",
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: ColorConstant.black900,
                          fontSize: getFontSize(
                            13,
                          ),
                          fontFamily: 'Inter',
                          fontWeight: FontWeight.w700,
                          height: 1.23,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
