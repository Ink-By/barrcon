import '../wish_list_screen/widgets/k1_item_widget.dart';
import 'package:barrrcon/core/app_export.dart';
import 'package:barrrcon/widgets/app_bar/appbar_image.dart';
import 'package:barrrcon/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class WishListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Padding(
          padding: getPadding(
            left: 8,
            top: 68,
            right: 10,
          ),
          child: ListView.builder(
            physics: BouncingScrollPhysics(),
            shrinkWrap: true,
            itemCount: 6,
            itemBuilder: (context, index) {
              return K1ItemWidget();
            },
          ),
        ),
      ),
    );
  }
}
