import 'package:barrrcon/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class K1ItemWidget extends StatelessWidget {
  K1ItemWidget();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: getMargin(
        top: 8.5,
        bottom: 8.5,
      ),
      padding: getPadding(
        top: 8,
        bottom: 8,
      ),
      decoration: BoxDecoration(
        color: ColorConstant.whiteA700,
        boxShadow: [
          BoxShadow(
            color: ColorConstant.black9003f,
            spreadRadius: getHorizontalSize(
              2.00,
            ),
            blurRadius: getHorizontalSize(
              2.00,
            ),
            offset: Offset(
              0,
              4,
            ),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          CustomImageView(
            imagePath: ImageConstant.twosome_cake,
            height: getVerticalSize(
              76.00,
            ),
            width: getHorizontalSize(
              75.00,
            ),
            margin: getMargin(
              top: 4,
              bottom: 3,
            ),
          ),
          Padding(
            padding: getPadding(
              top: 2,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                CustomImageView(
                  svgPath: ImageConstant.imgClose,
                  height: getVerticalSize(
                    13.00,
                  ),
                  width: getHorizontalSize(
                    11.00,
                  ),
                  alignment: Alignment.centerRight,
                ),
                Padding(
                  padding: getPadding(
                    top: 3,
                  ),
                  child: Text(
                    "투썸플레이스 밀크생크림 초콜릿 수플레",
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      color: ColorConstant.blueGray900,
                      fontSize: getFontSize(
                        14,
                      ),
                      fontFamily: 'Source Sans Pro',
                      fontWeight: FontWeight.w600,
                      height: 1.29,
                    ),
                  ),
                ),
                Container(
                  width: getHorizontalSize(
                    258.00,
                  ),
                  margin: getMargin(
                    top: 11,
                    right: 2,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: getPadding(
                          bottom: 17,
                        ),
                        child: Text(
                          "30,000원",
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.left,
                          style: TextStyle(
                            color: ColorConstant.black900,
                            fontSize: getFontSize(
                              14,
                            ),
                            fontFamily: 'Source Sans Pro',
                            fontWeight: FontWeight.w400,
                            height: 1.29,
                          ),
                        ),
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgBookmark,
                        height: getVerticalSize(
                          22.00,
                        ),
                        width: getHorizontalSize(
                          17.00,
                        ),
                        margin: getMargin(
                          top: 13,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
