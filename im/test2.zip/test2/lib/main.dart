import 'package:flutter/material.dart';

import 'submit.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'MAIN',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        initialRoute: '/'
        //routes: {},
        );
  }
}

class Main extends StatelessWidget {
  const Main({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          width: double.infinity,
          height: 855,
          child: Stack(
              fit: StackFit.expand,
              alignment: Alignment.center,
              clipBehavior: Clip.none,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.zero,
                  child: Container(
                    color: Color.fromARGB(255, 255, 255, 255),
                  ),
                ),
                Positioned(
                  left: 12.0,
                  top: 113.0,
                  right: null,
                  bottom: null,
                  width: 371.0,
                  height: 669.0,
                  child: GeneratedFrame40Widget(),
                ),
                Positioned(
                  left: 0.0,
                  top: 781.0,
                  right: null,
                  bottom: null,
                  width: 393.0,
                  height: 73.0,
                  child: GeneratedWidget34(),
                ),
                Positioned(
                  left: 19.0,
                  top: 69.16197204589844,
                  right: null,
                  bottom: null,
                  width: 56.0,
                  height: 21.838027954101562,
                  child: GeneratedWidget36(),
                ),
                Positioned(
                  left: 249.0,
                  top: 62.0,
                  right: null,
                  bottom: null,
                  width: 132.0,
                  height: 39.0,
                  child: GeneratedWidget38(),
                ),
                Positioned(
                  left: 1.0,
                  top: 0.0,
                  right: null,
                  bottom: null,
                  width: 393.0,
                  height: 110.0,
                  child: GeneratedHEADWidget(),
                )
              ]),
        ),
      ),
    );
  }
}
