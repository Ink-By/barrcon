import 'package:flutter/material.dart';

import 'main.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '상품 등록하기',
      home: Submit(),
    );
  }
}

class Submit extends StatefulWidget {
  const Submit({super.key});

  @override
  State<Submit> createState() => _SubmitState();
}

class _SubmitState extends State<Submit> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Image(
          image: AssetImage('assets/images/logo.png'),
          width: 200,
          height: 70,
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context); //뒤로가기
            },
            color: Colors.black),
        actions: <Widget>[
          IconButton(
              icon: const Icon(Icons.search),
              onPressed: () {},
              color: Colors.black)
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const Padding(
              padding: (EdgeInsets.only(top: 50)),
            ),
            /*--------- 사진 입력 부분 ---------*/
            Center(
                child: Container(
                    width: 350,
                    height: 170,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.black,
                        width: 5,
                      ),
                    )) /*-------------------------------*/
                ),
            Form(
              child: Theme(
                data: ThemeData(
                  primaryColor: Colors.black,
                  inputDecorationTheme: const InputDecorationTheme(
                      labelStyle:
                          TextStyle(color: Colors.black, fontSize: 15.0)),
                ),
                child: Container(
                  padding: const EdgeInsets.all(40.0),
                  child: Column(
                    children: [
                      const TextField(
                        decoration: InputDecoration(labelText: '상품명'),
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const TextField(
                        decoration: InputDecoration(labelText: '카테고리'),
                        keyboardType: TextInputType.text,
                      ),
                      const TextField(
                        decoration: InputDecoration(labelText: '유효기간'),
                        keyboardType: TextInputType.datetime,
                      ),
                      const TextField(
                        decoration: InputDecoration(labelText: '가격'),
                        keyboardType: TextInputType.text,
                      ),
                      const SizedBox(
                        height: 40.0,
                      ),
                      ButtonTheme(
                          minWidth: 100.0,
                          height: 50.0,
                          child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  primary: Colors.blueAccent),
                              child: const Text('등록'),
                              onPressed: () {}))
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
