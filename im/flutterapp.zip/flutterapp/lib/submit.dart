import 'package:flutter/material.dart';

class Submit extends StatelessWidget {
  const Submit({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          const Padding(
            padding: (EdgeInsets.only(top: 50)),
          ),
          /*--------- 사진 입력 부분 ---------*/
          Center(
              child: Container(
                  width: 350,
                  height: 170,
                  decoration: BoxDecoration(
                    border: Border.all(
                      color: Colors.black,
                      width: 5,
                    ),
                  ))
              ),
          /*-------------------------------*/
          Form(
            child: Theme(
              data: ThemeData(
                primaryColor: Colors.black,
                inputDecorationTheme: const InputDecorationTheme(
                    labelStyle: TextStyle(color: Colors.black, fontSize: 15.0)),
              ),
              child: Container(
                padding: const EdgeInsets.all(40.0),
                child: Column(
                  children: [
                    const TextField(
                      decoration: InputDecoration(labelText: '상품명'),
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const TextField(
                      decoration: InputDecoration(labelText: '카테고리'),
                      keyboardType: TextInputType.text,
                    ),
                    const TextField(
                      decoration: InputDecoration(labelText: '유효기간'),
                      keyboardType: TextInputType.datetime,
                    ),
                    const TextField(
                      decoration: InputDecoration(labelText: '가격'),
                      keyboardType: TextInputType.text,
                    ),
                    const SizedBox(
                      height: 40.0,
                    ),
                    ButtonTheme(
                        minWidth: 100.0,
                        height: 50.0,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                primary: Colors.blueAccent),
                            child: const Text('등록'),
                            onPressed: () {}))
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
