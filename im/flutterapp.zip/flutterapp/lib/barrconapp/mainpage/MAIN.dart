import 'package:flutter/material.dart';
import './maincomponents/MainScrollView.dart';
import '../../submit.dart';
import './maincomponents/AppbarLogo.dart';
import './maincomponents/AppbarRightIcon.dart';

class MAIN extends StatefulWidget {
  @override
  State<MAIN> createState() => _Main();
}

class _Main extends State<MAIN> {
  int _selectedIndex = 0;
  final List<Widget> _widgetOptions = <Widget>[
    MainScrollView(),
    Submit(),
    Submit(),
    Submit(),
    Submit()
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Container(
            width: 55,
            height: 22,
            child: AppbarLogo(),
          ),
          backgroundColor: Colors.white,
          actions: <Widget>[
            Container(
              width: 130,
              height: 40,
              child: AppbarRightIcon(),
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
            currentIndex: _selectedIndex,
            onTap: _onItemTapped,
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                  icon: Icon(Icons.home_outlined, size: 30), label: ''),
              BottomNavigationBarItem(
                  icon: Icon(Icons.bookmark, size: 30), label: ''),
              BottomNavigationBarItem(
                icon: Icon(Icons.add_circle, size: 50),
                label: '',
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.search, size: 30), label: ''),
              BottomNavigationBarItem(
                  icon: Icon(Icons.person, size: 30), label: ''),
            ],
            selectedItemColor: Colors.blueAccent,
            unselectedItemColor: Colors.black,
            showSelectedLabels: false,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed),
        body: Center(
          child: _widgetOptions.elementAt(_selectedIndex),
        ));
  }
}
