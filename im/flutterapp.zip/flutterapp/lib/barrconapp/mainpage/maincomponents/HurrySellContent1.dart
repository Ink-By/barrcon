import 'package:flutter/material.dart';
import './GeneratedD1Widget.dart';
import './GeneratedVectorWidget12.dart';
import './Generated4050Widget.dart';
import './Generated3Widget.dart';
import './Generated4500Widget.dart';
import './GeneratedWidget24.dart';
import './GeneratedTWidget.dart';
import './GeneratedWidget23.dart';
import './HurrySellImage1.dart';

class HurrySellContent1 extends StatelessWidget {
  const HurrySellContent1({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      width: 330.0,
      height: 90.0,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(0.0),
        border: Border.all(
          color: Colors.red,
          width: 3,
        ),
      ),
      child: Stack(
          fit: StackFit.expand,
          alignment: Alignment.center,
          clipBehavior: Clip.none,
          children: [
            Positioned(
              width: 330.0,
              height: 90.0,
              top:0,
              left:0,
              bottom:null,
              right:null,
              child: Generated3Widget(),
            ),
            Positioned(
              width: 90.0,
              height: 90.0,
              top:0,
              left:0,
              bottom:null,
              right:null,
              child: HurrySellImage1(),
            ),
            Positioned(
                width: 220.0,
                height: 70.0,
                top:10,
                left:100,
                bottom:null,
                right:null,
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                  Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      GeneratedWidget23(),
                      GeneratedTWidget(),
                    ]),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.baseline,
                        textBaseline: TextBaseline.ideographic,
                        children: [
                          Generated4500Widget(),
                          const SizedBox(width: 10),
                          Generated4050Widget()
                        ])
                  ]),
                  Column(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    GeneratedWidget24(),
                    GeneratedVectorWidget12(),
                    GeneratedD1Widget(),
                  ]),
                ])),
          ]),
    );
  }
}
