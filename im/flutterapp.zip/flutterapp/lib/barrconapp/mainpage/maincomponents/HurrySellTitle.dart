import 'package:flutter/material.dart';
import './HurrySellTitleText.dart';
import './HurrySellComment.dart';

class HurrySellTitle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        textBaseline: TextBaseline.ideographic,
        children: [
      Flexible(
        flex: 3,
        child: HurrySellTitleText()
      ),
      Flexible(
        flex: 10,
        child: HurrySellComment()
      ),
      Flexible(
        flex: 2,
        child: Container(height: 25),
      ),
      Flexible(
        flex: 1,
        child: Container(
          height: 50,
          child: Icon(Icons.add, size:40),
        ),
      ),
    ]);
  }
}
