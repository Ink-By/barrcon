import 'package:flutter/material.dart';
import './HurryBuy.dart';
import './HurrySell.dart';
import './AdPlace.dart';
import './CategoryInMain.dart';

class MainExceptAlarm extends StatelessWidget {
  const MainExceptAlarm({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
        child: Column(
      children: [
        const Padding(
          padding: (EdgeInsets.only(top: 5)),
        ),
        Container(
            margin: const EdgeInsets.only(top: 10),
            child: CategoryInMain()),
        Container(margin: const EdgeInsets.only(top: 40), child: HurryBuy()),
        Container(
            margin: const EdgeInsets.only(top: 40),
            child: HurrySell()),
        Container(
            width: double.infinity,
            height: 66.0,
            margin: const EdgeInsets.only(top: 40),
            child: AdPlace()),
      ],
    ));
  }
}
