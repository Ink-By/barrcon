import 'package:flutter/material.dart';
import './Fastfood.dart';
import './Caffee.dart';
import './ChichenPizza.dart';
import './ConvenienceStore.dart';
import './ViewMore.dart';

class Categories extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
      Flexible(
        flex: 1,
        child: Container(
          height: 80.0,
          child: Fastfood(),
        ),
      ),
      Flexible(
        flex: 1,
        child: Container(
          height: 80.0,
          child: Caffee(),
        ),
      ),
      Flexible(
        flex: 1,
        child: Container(
          height: 80.0,
          child: ChichenPizza(),
        ),
      ),
      Flexible(
        flex: 1,
        child: Container(
          height: 80.0,
          child: ConvenienceStore(),
        ),
      ),
      Flexible(
        flex: 1,
        child: Container(
          height: 80.0,
          child: ViewMore(),
        ),
      )
    ]));
  }
}
