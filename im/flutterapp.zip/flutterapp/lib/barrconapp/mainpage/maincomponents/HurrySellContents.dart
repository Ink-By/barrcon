import 'package:flutter/material.dart';
import './GeneratedGroup17Widget.dart';
import './GeneratedGroup15Widget.dart';
import './GeneratedGroup18Widget.dart';
import './GeneratedGroup16Widget.dart';
import './HurrySellContent1.dart';

class HurrySellContents extends StatelessWidget {
  const HurrySellContents({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: const EdgeInsets.fromLTRB(20,10,20,10),
      child :Column(
          children: [
            const HurrySellContent1(),
            GeneratedGroup15Widget(),
            GeneratedGroup16Widget(),
            GeneratedGroup16Widget(),
            GeneratedGroup17Widget(),
            GeneratedGroup18Widget(),]
      )
    );
  }
}
