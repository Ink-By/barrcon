import 'package:flutter/material.dart';

class HurryBuyContentTime1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Text(
      '''1 분 전''',
      textAlign: TextAlign.left,
      style: TextStyle(
        fontSize: 10.0,
        fontWeight: FontWeight.w700,
        color: Color.fromARGB(255, 114, 114, 114),
      ),
    );
  }
}
