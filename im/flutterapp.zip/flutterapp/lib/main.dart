import 'package:flutter/material.dart';
import './barrconapp/mainpage/maincomponents/MainScrollView.dart';
import './barrconapp/mainpage/MAIN.dart';
import './submit.dart';

void main() {
  runApp(BARRCONAPP());
}

class BARRCONAPP extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MainScrollView(),
      initialRoute: '/MAIN',
      routes: {
        '/MAIN': (context) => MAIN(),
        '/submit': (context) => Submit(),
      },
    );
  }
}
