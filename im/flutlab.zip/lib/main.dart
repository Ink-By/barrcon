import 'package:flutter/material.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/GeneratedMAINWidget.dart';

void main() {
  runApp(BARRCONAPP());
}

class BARRCONAPP extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedMAINWidget',
      routes: {
        '/GeneratedMAINWidget': (context) => GeneratedMAINWidget(),
      },
    );
  }
}
