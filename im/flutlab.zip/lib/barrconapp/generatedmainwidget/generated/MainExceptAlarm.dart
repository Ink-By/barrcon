import 'package:flutter/material.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/HurryBuy.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/HurrySell.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/AdPlace.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/CategoryInMain.dart';

class MainExceptAlarm extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: Column(
      children: [
        const Padding(
          padding: (EdgeInsets.only(top: 5)),
        ),
        Container(
            width: double.infinity,
            height: 140.0,
            child: CategoryInMain(),
            margin: EdgeInsets.only(top: 10)),
        Container(
            width: double.infinity,
            height: 138.0,
            child: HurryBuy(),
            margin: EdgeInsets.only(top: 10)),
        Container(
            width: double.infinity,
            height: 573.0,
            child: HurrySell(),
            margin: EdgeInsets.only(top: 10)),
        Container(
            width: double.infinity,
            height: 66.0,
            child: AdPlace(),
            margin: EdgeInsets.only(top: 10)),
      ],
    ));
  }
}
