import 'package:flutter/material.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/ChickenIcon.dart';

class ChichenPizza extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(
        child: ChickenIcon(),
      ),
      SizedBox(height: 5),
      Container(
          child: Text(
        '''치킨/피자''',
        overflow: TextOverflow.visible,
        textAlign: TextAlign.left,
        style: TextStyle(
          height: 1,
          fontSize: 12.0,
          fontFamily: 'Inter',
          fontWeight: FontWeight.w600,
          color: Colors.black,
        ),
      ))
    ]);
  }
}
