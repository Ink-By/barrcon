import 'package:flutter/material.dart';

class FastfoodIcon extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Ink(
      width: 55,
      height: 55,
      decoration: const ShapeDecoration(
        color: Color.fromARGB(255, 217, 217, 217),
        shape: CircleBorder(),
      ),
      child: IconButton(
        onPressed: () {},
        icon: Icon(Icons.fastfood, size: 30),
        iconSize: 20,
        color: Colors.black,
      ),
    );
  }
}
