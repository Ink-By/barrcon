import 'package:flutter/material.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/Fastfood.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/Caffee.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/ChichenPizza.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/ConvenienceStore.dart';
import 'package:flutterapp/barrconapp/generatedmainwidget/generated/ViewMore.dart';

class Categories extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(
        width: 70.0,
        height: 80.0,
        child: Fastfood(),
      ),
      Container(
        width: 70.0,
        height: 80.0,
        child: Caffee(),
      ),
      Container(
        width: 70.0,
        height: 80.0,
        child: ChichenPizza(),
      ),
      Container(
        width: 70.0,
        height: 80.0,
        child: ConvenienceStore(),
      ),
      Container(
        width: 70.0,
        height: 80.0,
        child: ViewMore(),
      )
    ]));
  }
}
